package com.zeesh.docscanner

import android.content.Context
import java.io.File
import kotlin.math.max

/** Remembers when each document was last opened, for the "Recent" section. */
class RecentStore(context: Context) {

    private val prefs = context.getSharedPreferences("recent_docs", Context.MODE_PRIVATE)

    fun touch(file: File) {
        prefs.edit().putLong(file.absolutePath, System.currentTimeMillis()).apply()
    }

    fun remove(file: File) {
        prefs.edit().remove(file.absolutePath).apply()
    }

    fun move(from: File, to: File) {
        val t = prefs.getLong(from.absolutePath, 0L)
        val editor = prefs.edit().remove(from.absolutePath)
        if (t > 0L) editor.putLong(to.absolutePath, t)
        editor.apply()
    }

    /** Most recent of "opened" and "changed". */
    fun lastUsed(file: File): Long = max(prefs.getLong(file.absolutePath, 0L), file.lastModified())
}
