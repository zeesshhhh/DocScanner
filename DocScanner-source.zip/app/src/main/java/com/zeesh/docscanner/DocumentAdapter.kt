package com.zeesh.docscanner

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.util.LruCache
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.zeesh.docscanner.databinding.ItemDocumentBinding
import com.zeesh.docscanner.databinding.ItemMergeBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DocumentAdapter(
    private val scope: CoroutineScope,
    private val onClick: (File) -> Unit,
    private val onLongClick: (File) -> Unit,
    private val onMenu: (File, View) -> Unit,
) : RecyclerView.Adapter<DocumentAdapter.VH>() {

    class VH(val b: ItemDocumentBinding) : RecyclerView.ViewHolder(b.root) {
        var job: Job? = null
        var key: String? = null
    }

    private var items: List<DocInfo> = emptyList()
    private val selected = LinkedHashSet<String>()
    private val dateFmt = SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault())
    private val thumbs = object : LruCache<String, Bitmap>(16 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    var selectionMode = false
        private set

    val selectedCount: Int get() = selected.size

    @SuppressLint("NotifyDataSetChanged")
    fun submit(list: List<DocInfo>) {
        items = list
        val paths = list.map { it.file.absolutePath }.toSet()
        selected.retainAll(paths)
        notifyDataSetChanged()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun startSelection(first: File?) {
        selectionMode = true
        first?.let { selected.add(it.absolutePath) }
        notifyDataSetChanged()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun clearSelection() {
        selectionMode = false
        selected.clear()
        notifyDataSetChanged()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun selectAll() {
        selectionMode = true
        items.forEach { selected.add(it.file.absolutePath) }
        notifyDataSetChanged()
    }

    fun toggle(file: File) {
        val p = file.absolutePath
        if (!selected.remove(p)) selected.add(p)
        val idx = items.indexOfFirst { it.file.absolutePath == p }
        if (idx >= 0) notifyItemChanged(idx)
    }

    /** Selected files in the order they were tapped. */
    fun selectedFiles(): List<File> = selected.map { File(it) }.filter { it.exists() }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemDocumentBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val info = items[position]
        val f = info.file
        h.b.name.text = f.nameWithoutExtension
        val pages = if (info.pages == 1) "1 page" else "${info.pages} pages"
        h.b.info.text = "$pages  •  ${formatSize(info.size)}\n${dateFmt.format(Date(info.modified))}"
        h.b.card.isChecked = selectionMode && f.absolutePath in selected
        h.b.more.isVisible = !selectionMode
        h.b.card.setOnClickListener { onClick(f) }
        h.b.card.setOnLongClickListener { onLongClick(f); true }
        h.b.more.setOnClickListener { onMenu(f, it) }

        val key = f.absolutePath + ":" + info.modified
        h.key = key
        h.job?.cancel()
        val cached = thumbs.get(key)
        if (cached != null) {
            h.b.thumb.setImageBitmap(cached)
            return
        }
        h.b.thumb.setImageDrawable(null)
        h.job = scope.launch {
            val bmp = withContext(Dispatchers.IO) { PdfTools.thumbnail(f, 200) }
            if (bmp != null) {
                thumbs.put(key, bmp)
                if (h.key == key) h.b.thumb.setImageBitmap(bmp)
            }
        }
    }
}

data class MergeItem(val name: String, val file: File)

class MergeAdapter(
    private val items: MutableList<MergeItem>,
    private val onStartDrag: (RecyclerView.ViewHolder) -> Unit,
) : RecyclerView.Adapter<MergeAdapter.VH>() {

    class VH(val b: ItemMergeBinding) : RecyclerView.ViewHolder(b.root)

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemMergeBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    @SuppressLint("ClickableViewAccessibility")
    override fun onBindViewHolder(h: VH, position: Int) {
        val item = items[position]
        h.b.index.text = (position + 1).toString()
        h.b.name.text = item.name
        h.b.handle.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) onStartDrag(h)
            false
        }
    }
}
