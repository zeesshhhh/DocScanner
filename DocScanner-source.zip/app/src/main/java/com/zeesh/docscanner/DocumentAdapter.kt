package com.zeesh.docscanner

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.text.format.DateUtils
import android.util.LruCache
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.zeesh.docscanner.databinding.ItemDocumentBinding
import com.zeesh.docscanner.databinding.ItemMergeBinding
import com.zeesh.docscanner.databinding.ItemRecentBinding
import com.zeesh.docscanner.databinding.SectionRecentBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Loads and caches first-page thumbnails for document lists. */
class ThumbLoader(private val scope: CoroutineScope) {

    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun load(view: ImageView, file: File, widthPx: Int) {
        val key = "${file.absolutePath}:${file.lastModified()}:${file.length()}:$widthPx"
        view.tag = key
        val cached = cache.get(key)
        if (cached != null) {
            view.setImageBitmap(cached)
            return
        }
        view.setImageDrawable(null)
        scope.launch {
            val bmp = withContext(Dispatchers.IO) { PdfTools.thumbnail(file, widthPx) }
            if (bmp != null) {
                cache.put(key, bmp)
                if (view.tag == key) view.setImageBitmap(bmp)
            }
        }
    }
}

const val THUMB_WIDTH = 240

class DocumentAdapter(
    private val thumbs: ThumbLoader,
    private val onClick: (File) -> Unit,
    private val onLongClick: (File) -> Unit,
    private val onMenu: (File, View) -> Unit,
) : RecyclerView.Adapter<DocumentAdapter.VH>() {

    class VH(val b: ItemDocumentBinding) : RecyclerView.ViewHolder(b.root)

    private var items: List<DocInfo> = emptyList()
    private val selected = LinkedHashSet<String>()
    private val dateFmt = SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault())

    var selectionMode = false
        private set

    val selectedCount: Int get() = selected.size

    @SuppressLint("NotifyDataSetChanged")
    fun submit(list: List<DocInfo>) {
        items = list
        val paths = list.map { it.file.absolutePath }.toSet()
        selected.retainAll(paths)
        notifyDataSetChanged()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun startSelection(first: File?) {
        selectionMode = true
        first?.let { selected.add(it.absolutePath) }
        notifyDataSetChanged()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun clearSelection() {
        selectionMode = false
        selected.clear()
        notifyDataSetChanged()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun selectAll() {
        selectionMode = true
        items.forEach { selected.add(it.file.absolutePath) }
        notifyDataSetChanged()
    }

    fun toggle(file: File) {
        val p = file.absolutePath
        if (!selected.remove(p)) selected.add(p)
        val idx = items.indexOfFirst { it.file.absolutePath == p }
        if (idx >= 0) notifyItemChanged(idx)
    }

    /** Selected files in the order they were tapped. */
    fun selectedFiles(): List<File> = selected.map { File(it) }.filter { it.exists() }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemDocumentBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val info = items[position]
        val f = info.file
        h.b.name.text = f.nameWithoutExtension
        val pages = if (info.pages == 1) "1 page" else "${info.pages} pages"
        h.b.info.text = "$pages  •  ${formatSize(info.size)}\n${dateFmt.format(Date(info.modified))}"
        h.b.card.isChecked = selectionMode && f.absolutePath in selected
        h.b.more.isVisible = !selectionMode
        h.b.card.setOnClickListener { onClick(f) }
        h.b.card.setOnLongClickListener { onLongClick(f); true }
        h.b.more.setOnClickListener { onMenu(f, it) }
        thumbs.load(h.b.thumb, f, THUMB_WIDTH)
    }
}

/** Horizontal strip of recently opened / changed documents. */
class RecentAdapter(
    private val thumbs: ThumbLoader,
    private val onClick: (File) -> Unit,
    private val onLongClick: (File, View) -> Unit,
) : RecyclerView.Adapter<RecentAdapter.VH>() {

    class VH(val b: ItemRecentBinding) : RecyclerView.ViewHolder(b.root)

    private var items: List<Pair<DocInfo, Long>> = emptyList()

    @SuppressLint("NotifyDataSetChanged")
    fun submit(list: List<Pair<DocInfo, Long>>) {
        items = list
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemRecentBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val (info, used) = items[position]
        val f = info.file
        h.b.name.text = f.nameWithoutExtension
        h.b.time.text = DateUtils.getRelativeTimeSpanString(used, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS)
        h.b.card.setOnClickListener { onClick(f) }
        h.b.card.setOnLongClickListener { v ->
            onLongClick(f, v)
            true
        }
        thumbs.load(h.b.thumb, f, THUMB_WIDTH)
    }
}

/** First row of the home list: "Recent" strip + "My documents" title. */
class SectionHeaderAdapter(
    private val recentAdapter: RecentAdapter,
) : RecyclerView.Adapter<SectionHeaderAdapter.VH>() {

    class VH(val b: SectionRecentBinding) : RecyclerView.ViewHolder(b.root)

    private var showRecent = false
    private var docCount = 0

    fun update(showRecent: Boolean, docCount: Int) {
        this.showRecent = showRecent
        this.docCount = docCount
        notifyItemChanged(0, PAYLOAD_UPDATE)
    }

    override fun getItemCount(): Int = 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = SectionRecentBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        b.recentList.layoutManager = LinearLayoutManager(parent.context, LinearLayoutManager.HORIZONTAL, false)
        b.recentList.adapter = recentAdapter
        return VH(b)
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        h.b.recentTitle.isVisible = showRecent
        h.b.recentList.isVisible = showRecent
        h.b.docsTitle.isVisible = docCount > 0
        h.b.docsTitle.text = h.b.root.context.getString(R.string.my_documents) + " ($docCount)"
    }

    companion object {
        private const val PAYLOAD_UPDATE = "update"
    }
}

data class MergeItem(val name: String, val file: File)

class MergeAdapter(
    private val items: MutableList<MergeItem>,
    private val onStartDrag: (RecyclerView.ViewHolder) -> Unit,
) : RecyclerView.Adapter<MergeAdapter.VH>() {

    class VH(val b: ItemMergeBinding) : RecyclerView.ViewHolder(b.root)

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemMergeBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    @SuppressLint("ClickableViewAccessibility")
    override fun onBindViewHolder(h: VH, position: Int) {
        val item = items[position]
        h.b.index.text = (position + 1).toString()
        h.b.name.text = item.name
        h.b.handle.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) onStartDrag(h)
            false
        }
    }
}
