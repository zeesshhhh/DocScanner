package com.zeesh.docscanner

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DocInfo(val file: File, val pages: Int, val size: Long, val modified: Long)

/** Stores the user's PDFs in the app's private "documents" folder. */
class DocRepository(private val context: Context) {

    val dir: File = File(context.filesDir, "documents").apply { mkdirs() }

    fun list(): List<File> =
        dir.listFiles { f -> f.isFile && f.name.endsWith(".pdf", ignoreCase = true) }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()

    fun loadInfos(): List<DocInfo> =
        list().map { DocInfo(it, PdfTools.pageCount(it), it.length(), it.lastModified()) }

    fun defaultName(prefix: String): String =
        prefix + "_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    fun sanitize(name: String): String =
        name.trim()
            .replace(Regex("(?i)\\.pdf$"), "")
            .replace(Regex("[\\\\/:*?\"<>|\\n\\r\\t]"), "_")
            .trim()
            .take(120)

    /** A file in the documents folder with this name that doesn't exist yet. */
    fun uniqueFile(baseName: String): File {
        val clean = sanitize(baseName).ifBlank { defaultName("Document") }
        var f = File(dir, "$clean.pdf")
        var i = 2
        while (f.exists()) {
            f = File(dir, "$clean ($i).pdf")
            i++
        }
        return f
    }

    fun importUri(uri: Uri, name: String): File {
        val out = uniqueFile(name)
        try {
            val input = context.contentResolver.openInputStream(uri)
                ?: throw IOException("Couldn't open the file")
            input.use { inp -> out.outputStream().use { inp.copyTo(it) } }
        } catch (e: Exception) {
            out.delete()
            throw e
        }
        return out
    }

    fun copyToCache(uri: Uri, fileName: String): File {
        val out = File(context.cacheDir, fileName)
        val input = context.contentResolver.openInputStream(uri)
            ?: throw IOException("Couldn't open the file")
        input.use { inp -> out.outputStream().use { inp.copyTo(it) } }
        return out
    }

    fun rename(file: File, newName: String): File? {
        val clean = sanitize(newName)
        if (clean.isBlank()) return null
        if (clean == file.nameWithoutExtension) return file
        val target = uniqueFile(clean)
        return if (file.renameTo(target)) target else null
    }

    fun displayName(uri: Uri): String {
        var name: String? = null
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) name = c.getString(0) }
        } catch (_: Exception) {
        }
        val raw = name ?: uri.lastPathSegment ?: "Document"
        return sanitize(raw.substringAfterLast('/')).ifBlank { "Document" }
    }
}
