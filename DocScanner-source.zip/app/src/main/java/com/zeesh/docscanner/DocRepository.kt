package com.zeesh.docscanner

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DocInfo(val file: File, val pages: Int, val size: Long, val modified: Long, val created: Long)

enum class SortOrder(val label: String) {
    CREATED("Date created (newest first)"),
    MODIFIED("Last changed"),
    NAME("Name (A to Z)"),
    SIZE("Size (largest first)")
}

/** Stores the user's PDFs in the app's private "documents" folder. */
class DocRepository(private val context: Context) {

    val dir: File = File(context.filesDir, "documents").apply { mkdirs() }

    // When each document was first seen, so editing a document doesn't move it in the list.
    private val createdPrefs = context.getSharedPreferences("doc_created", Context.MODE_PRIVATE)
    private val settings = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var sortOrder: SortOrder
        get() = settings.getString("sort", null)
            ?.let { n -> SortOrder.entries.firstOrNull { it.name == n } }
            ?: SortOrder.CREATED
        set(value) {
            settings.edit().putString("sort", value.name).apply()
        }

    private fun pdfFiles(): List<File> =
        dir.listFiles { f -> f.isFile && f.name.endsWith(".pdf", ignoreCase = true) }?.toList() ?: emptyList()

    fun createdTime(file: File): Long {
        val key = file.absolutePath
        val saved = createdPrefs.getLong(key, 0L)
        if (saved > 0L) return saved
        val t = file.lastModified().takeIf { it > 0L } ?: System.currentTimeMillis()
        createdPrefs.edit().putLong(key, t).apply()
        return t
    }

    private fun moveCreated(from: File, to: File) {
        val t = createdPrefs.getLong(from.absolutePath, 0L)
        val editor = createdPrefs.edit().remove(from.absolutePath)
        if (t > 0L) editor.putLong(to.absolutePath, t)
        editor.apply()
    }

    /** Newest first by creation time. */
    fun list(): List<File> = pdfFiles().sortedByDescending { createdTime(it) }

    /** Documents in the order chosen in "Sort by" (same order as the home list). */
    fun orderedFiles(): List<File> {
        val files = pdfFiles()
        return when (sortOrder) {
            SortOrder.CREATED -> files.sortedByDescending { createdTime(it) }
            SortOrder.MODIFIED -> files.sortedByDescending { it.lastModified() }
            SortOrder.NAME -> files.sortedBy { it.nameWithoutExtension.lowercase(Locale.getDefault()) }
            SortOrder.SIZE -> files.sortedByDescending { it.length() }
        }
    }

    fun loadInfos(): List<DocInfo> =
        orderedFiles().map { DocInfo(it, PdfTools.pageCount(it), it.length(), it.lastModified(), createdTime(it)) }

    fun defaultName(prefix: String): String =
        prefix + "_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    fun sanitize(name: String): String =
        name.trim()
            .replace(Regex("(?i)\\.pdf$"), "")
            .replace(Regex("[\\\\/:*?\"<>|\\n\\r\\t]"), "_")
            .trim()
            .take(120)

    /** A file in the documents folder with this name that doesn't exist yet. */
    fun uniqueFile(baseName: String): File {
        val clean = sanitize(baseName).ifBlank { defaultName("Document") }
        var f = File(dir, "$clean.pdf")
        var i = 2
        while (f.exists()) {
            f = File(dir, "$clean ($i).pdf")
            i++
        }
        return f
    }

    fun importUri(uri: Uri, name: String): File {
        val out = uniqueFile(name)
        try {
            val input = context.contentResolver.openInputStream(uri)
                ?: throw IOException("Couldn't open the file")
            input.use { inp -> out.outputStream().use { inp.copyTo(it) } }
        } catch (e: Exception) {
            out.delete()
            throw e
        }
        return out
    }

    fun copyToCache(uri: Uri, fileName: String): File {
        val out = File(context.cacheDir, fileName)
        val input = context.contentResolver.openInputStream(uri)
            ?: throw IOException("Couldn't open the file")
        input.use { inp -> out.outputStream().use { inp.copyTo(it) } }
        return out
    }

    fun rename(file: File, newName: String): File? {
        val clean = sanitize(newName)
        if (clean.isBlank()) return null
        if (clean == file.nameWithoutExtension) return file
        val target = uniqueFile(clean)
        if (!file.renameTo(target)) return null
        moveCreated(file, target)
        return target
    }

    fun delete(file: File): Boolean {
        createdPrefs.edit().remove(file.absolutePath).apply()
        return file.delete()
    }

    /** Puts [replacement]'s contents in place of [original], keeping the original's name and list position. */
    fun replaceWith(original: File, replacement: File): Boolean {
        val target = File(original.absolutePath)
        if (!original.delete()) return false
        val ok = replacement.renameTo(target)
        createdPrefs.edit().remove(replacement.absolutePath).apply()
        return ok
    }

    fun displayName(uri: Uri): String {
        var name: String? = null
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) name = c.getString(0) }
        } catch (_: Exception) {
        }
        val raw = name ?: uri.lastPathSegment ?: "Document"
        return sanitize(raw.substringAfterLast('/')).ifBlank { "Document" }
    }
}
