package com.zeesh.docscanner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.exifinterface.media.ExifInterface
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object PdfTools {

    /** Compression presets: render resolution, max pixel size and JPEG quality. */
    enum class Level(val dpi: Int, val maxPx: Int, val jpegQuality: Int) {
        SMALL(100, 1300, 45),
        MEDIUM(150, 1800, 60),
        HIGH(200, 2500, 80)
    }

    private fun openRenderer(file: File): PdfRenderer =
        PdfRenderer(ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY))

    fun pageCount(file: File): Int = try {
        openRenderer(file).use { it.pageCount }
    } catch (e: Exception) {
        0
    }

    fun thumbnail(file: File, widthPx: Int): Bitmap? = try {
        openRenderer(file).use { r ->
            if (r.pageCount == 0) null else r.openPage(0).use { p -> renderPage(p, widthPx) }
        }
    } catch (e: Exception) {
        null
    }

    /** Renders a page onto a white bitmap of the given width (height follows the page's aspect ratio). */
    fun renderPage(page: PdfRenderer.Page, widthPx: Int): Bitmap {
        val w = widthPx.coerceAtLeast(1)
        val h = (w.toFloat() * page.height / page.width).roundToInt().coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        return bmp
    }

    /** Merges PDFs in order. Falls back to re-rendering pages if a file can't be merged directly. */
    fun merge(context: Context, inputs: List<File>, output: File) {
        try {
            val merger = PDFMergerUtility()
            merger.setDestinationFileName(output.absolutePath)
            for (f in inputs) merger.addSource(f)
            merger.mergeDocuments(MemoryUsageSetting.setupTempFileOnly().setTempDir(context.cacheDir))
        } catch (e: Exception) {
            output.delete()
            rasterize(inputs, output, Level.HIGH, false, null)
        }
    }

    /** Reduces file size by re-saving every page as an optimized JPEG. */
    fun compress(input: File, output: File, level: Level, grayscale: Boolean, progress: (Int, Int) -> Unit) {
        rasterize(listOf(input), output, level, grayscale, progress)
    }

    private fun rasterize(
        inputs: List<File>,
        output: File,
        level: Level,
        grayscale: Boolean,
        progress: ((Int, Int) -> Unit)?
    ) {
        val total = inputs.sumOf { pageCount(it) }
        if (total == 0) throw IOException("This PDF couldn't be read (it may be password protected)")
        var done = 0
        PDDocument().use { doc ->
            for (input in inputs) {
                openRenderer(input).use { renderer ->
                    for (i in 0 until renderer.pageCount) {
                        renderer.openPage(i).use { page ->
                            val wPt = page.width.toFloat()
                            val hPt = page.height.toFloat()
                            val scale = min(level.dpi / 72f, level.maxPx / max(wPt, hPt))
                            val bw = (wPt * scale).roundToInt().coerceAtLeast(1)
                            val rendered = renderPage(page, bw)
                            val bmp = if (grayscale) toGrayscale(rendered).also { rendered.recycle() } else rendered
                            addJpegPage(doc, bmp, level.jpegQuality, wPt, hPt)
                            bmp.recycle()
                        }
                        done++
                        progress?.invoke(done, total)
                    }
                }
            }
            doc.save(output)
        }
    }

    /** Builds a PDF with one page per image. */
    fun imagesToPdf(context: Context, uris: List<Uri>, output: File, progress: (Int, Int) -> Unit) {
        PDDocument().use { doc ->
            uris.forEachIndexed { i, uri ->
                progress(i + 1, uris.size)
                val decoded: Bitmap? = try {
                    decodeImage(context, uri, 2400)
                } catch (e: Exception) {
                    null
                }
                val bmp = decoded ?: return@forEachIndexed
                val wPt = PDRectangle.A4.width
                val hPt = wPt * bmp.height / bmp.width
                addJpegPage(doc, bmp, 82, wPt, hPt)
                bmp.recycle()
            }
            if (doc.numberOfPages == 0) throw IOException("Couldn't read any of the selected images")
            doc.save(output)
        }
    }

    private fun addJpegPage(doc: PDDocument, bmp: Bitmap, quality: Int, wPt: Float, hPt: Float) {
        val bytes = ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG, quality, it) }.toByteArray()
        val image = JPEGFactory.createFromStream(doc, ByteArrayInputStream(bytes))
        val page = PDPage(PDRectangle(wPt, hPt))
        doc.addPage(page)
        PDPageContentStream(doc, page).use { cs -> cs.drawImage(image, 0f, 0f, wPt, hPt) }
    }

    private fun toGrayscale(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        paint.colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
        Canvas(out).drawBitmap(src, 0f, 0f, paint)
        return out
    }

    private fun decodeImage(context: Context, uri: Uri, maxSide: Int): Bitmap? {
        val cr = context.contentResolver

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val boundsStream = cr.openInputStream(uri) ?: return null
        boundsStream.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val stream = cr.openInputStream(uri) ?: return null
        var bmp: Bitmap = stream.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null

        val longSide = max(bmp.width, bmp.height)
        if (longSide > maxSide) {
            val s = maxSide.toFloat() / longSide
            val scaled = Bitmap.createScaledBitmap(
                bmp, (bmp.width * s).roundToInt().coerceAtLeast(1), (bmp.height * s).roundToInt().coerceAtLeast(1), true
            )
            if (scaled != bmp) bmp.recycle()
            bmp = scaled
        }

        val orientation = try {
            cr.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { matrix.postRotate(90f); matrix.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { matrix.postRotate(270f); matrix.postScale(-1f, 1f) }
        }
        if (!matrix.isIdentity) {
            val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, matrix, true)
            if (rotated != bmp) bmp.recycle()
            bmp = rotated
        }

        // Transparent PNGs would turn black as JPEG; put them on white.
        if (bmp.hasAlpha()) {
            val flat = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
            Canvas(flat).apply {
                drawColor(Color.WHITE)
                drawBitmap(bmp, 0f, 0f, null)
            }
            bmp.recycle()
            bmp = flat
        }
        return bmp
    }
}
