package com.zeesh.docscanner

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.util.LruCache
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.zeesh.docscanner.databinding.ActivityViewerBinding
import com.zeesh.docscanner.databinding.ItemPageBinding
import kotlinx.coroutines.Job
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.min
import kotlin.math.roundToInt

/** Simple in-app PDF viewer: pages rendered one below another. */
class ViewerActivity : AppCompatActivity() {

    private lateinit var b: ActivityViewerBinding
    private lateinit var file: File
    private var renderer: PdfRenderer? = null

    // PdfRenderer is not thread-safe, so all rendering happens on one background thread.
    private val renderExecutor = Executors.newSingleThreadExecutor()
    private val renderDispatcher = renderExecutor.asCoroutineDispatcher()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        b = ActivityViewerBinding.inflate(layoutInflater)
        setContentView(b.root)
        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        val path = intent.getStringExtra(EXTRA_PATH)
        if (path == null) {
            finish()
            return
        }
        file = File(path)
        b.toolbar.title = file.nameWithoutExtension
        b.toolbar.setNavigationOnClickListener { finish() }
        b.toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_share -> FileActions.share(this, listOf(file))
                R.id.action_open_with -> FileActions.openWith(this, file)
            }
            true
        }
        b.pages.layoutManager = LinearLayoutManager(this)

        lifecycleScope.launch {
            // Open the PDF and read every page's aspect ratio so placeholders have the right height.
            val ratios: List<Float>? = withContext(renderDispatcher) {
                try {
                    val r = PdfRenderer(ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY))
                    renderer = r
                    (0 until r.pageCount).map { i -> r.openPage(i).use { p -> p.height.toFloat() / p.width } }
                } catch (e: Exception) {
                    null
                }
            }
            if (ratios == null) {
                toast("Can't open this PDF")
                finish()
                return@launch
            }
            b.toolbar.subtitle = if (ratios.size == 1) "1 page" else "${ratios.size} pages"
            b.pages.adapter = PageAdapter(ratios)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        val r = renderer
        renderExecutor.execute { runCatching { r?.close() } }
        renderExecutor.shutdown()
    }

    class PageVH(val b: ItemPageBinding) : RecyclerView.ViewHolder(b.root) {
        var job: Job? = null
    }

    private inner class PageAdapter(private val ratios: List<Float>) : RecyclerView.Adapter<PageVH>() {

        private val cache = object : LruCache<Int, Bitmap>(48 * 1024 * 1024) {
            override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
        }

        override fun getItemCount(): Int = ratios.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH =
            PageVH(ItemPageBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        override fun onBindViewHolder(h: PageVH, position: Int) {
            h.job?.cancel()
            h.b.pageNumber.text = "${position + 1} / ${ratios.size}"

            val itemPad = h.itemView.paddingLeft + h.itemView.paddingRight
            val width = (b.pages.width - itemPad).takeIf { it > 0 } ?: (resources.displayMetrics.widthPixels - itemPad)
            val lp = h.b.pageImage.layoutParams
            lp.height = (width * ratios[position]).roundToInt()
            h.b.pageImage.layoutParams = lp

            val cached = cache.get(position)
            if (cached != null) {
                h.b.pageImage.setImageBitmap(cached)
                return
            }
            h.b.pageImage.setImageDrawable(null)
            val renderWidth = min(width, 1600)
            h.job = lifecycleScope.launch {
                val bmp = withContext(renderDispatcher) {
                    runCatching {
                        renderer?.openPage(position)?.use { p -> PdfTools.renderPage(p, renderWidth) }
                    }.getOrNull()
                }
                if (bmp != null) {
                    cache.put(position, bmp)
                    h.b.pageImage.setImageBitmap(bmp)
                }
            }
        }
    }

    companion object {
        const val EXTRA_PATH = "path"
    }
}
