package com.zeesh.docscanner

import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.util.LruCache
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.PagerSnapHelper
import androidx.recyclerview.widget.RecyclerView
import com.zeesh.docscanner.databinding.ActivityViewerBinding
import com.zeesh.docscanner.databinding.ItemDocNavBinding
import com.zeesh.docscanner.databinding.ItemPageBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * PDF viewer. Swipe left/right through pages (or scroll up/down), pinch to zoom.
 * Swiping past the last/first page moves to the next/previous document.
 */
class ViewerActivity : AppCompatActivity() {

    private lateinit var b: ActivityViewerBinding
    private lateinit var file: File
    private lateinit var repo: DocRepository
    private var renderer: PdfRenderer? = null
    private var pageAdapter: PageAdapter? = null
    private var docs: List<File> = emptyList()
    private var horizontal = true
    private var loading = false
    private val snapHelper = PagerSnapHelper()

    // PdfRenderer is not thread-safe, so all rendering happens on one background thread.
    private val renderExecutor = Executors.newSingleThreadExecutor()
    private val renderDispatcher = renderExecutor.asCoroutineDispatcher()

    private val editLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == RESULT_OK) openDocument(file, currentPage())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        b = ActivityViewerBinding.inflate(layoutInflater)
        setContentView(b.root)
        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        val path = intent.getStringExtra(EXTRA_PATH)
        if (path == null) {
            finish()
            return
        }
        file = File(path)
        repo = DocRepository(this)
        horizontal = getSharedPreferences("viewer", MODE_PRIVATE).getBoolean("horizontal", true)

        b.toolbar.title = file.nameWithoutExtension
        b.toolbar.setNavigationOnClickListener { finish() }
        b.toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_edit -> editLauncher.launch(
                    Intent(this, EditorActivity::class.java).putExtra(EditorActivity.EXTRA_PATH, file.absolutePath)
                )
                R.id.action_share -> FileActions.share(this, listOf(file))
                R.id.action_open_with -> FileActions.openWith(this, file)
                R.id.action_layout -> toggleLayout()
            }
            true
        }
        updateLayoutMenuTitle()

        setupLayoutManager()
        b.pages.onZoomSettled = { z -> onZoomSettled(z) }
        b.pages.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_IDLE) onSettled()
            }
        })

        lifecycleScope.launch {
            docs = withContext(Dispatchers.IO) { repo.orderedFiles() }
            openDocument(file, 0)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        renderExecutor.execute { runCatching { renderer?.close() } }
        renderExecutor.shutdown()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val page = currentPage()
        val adapter = pageAdapter ?: return
        adapter.clearCache()
        adapter.notifyDataSetChanged()
        b.pages.post { scrollToPage(page) }
    }

    // ---------- Layout (swipe vs scroll) ----------

    private fun setupLayoutManager() {
        val orientation = if (horizontal) RecyclerView.HORIZONTAL else RecyclerView.VERTICAL
        b.pages.layoutManager = LinearLayoutManager(this, orientation, false)
        snapHelper.attachToRecyclerView(if (horizontal) b.pages else null)
    }

    private fun toggleLayout() {
        val page = currentPage()
        horizontal = !horizontal
        getSharedPreferences("viewer", MODE_PRIVATE).edit().putBoolean("horizontal", horizontal).apply()
        b.pages.resetZoom()
        setupLayoutManager()
        pageAdapter?.let {
            it.clearCache()
            it.notifyDataSetChanged()
        }
        b.pages.post { scrollToPage(page) }
        updateLayoutMenuTitle()
        toast(if (horizontal) "Swipe left/right to change page" else "Scroll up/down through pages")
    }

    private fun updateLayoutMenuTitle() {
        b.toolbar.menu.findItem(R.id.action_layout)?.title =
            if (horizontal) "Scroll pages up/down" else "Swipe pages left/right"
    }

    // ---------- Documents & pages ----------

    /** Opens [target] at [startPage] (-1 = last page). */
    private fun openDocument(target: File, startPage: Int) {
        if (loading) return
        loading = true
        lifecycleScope.launch {
            val ratios: List<Float>? = withContext(renderDispatcher) {
                runCatching { renderer?.close() }
                renderer = null
                try {
                    val r = PdfRenderer(ParcelFileDescriptor.open(target, ParcelFileDescriptor.MODE_READ_ONLY))
                    renderer = r
                    (0 until r.pageCount).map { i -> r.openPage(i).use { p -> p.height.toFloat() / p.width } }
                } catch (e: Exception) {
                    null
                }
            }
            loading = false
            if (ratios.isNullOrEmpty()) {
                toast("Can't open this PDF")
                if (pageAdapter == null) finish()
                return@launch
            }
            file = target
            intent.putExtra(EXTRA_PATH, target.absolutePath)
            RecentStore(this@ViewerActivity).touch(target)
            b.toolbar.title = target.nameWithoutExtension

            val idx = docs.indexOfFirst { it.absolutePath == target.absolutePath }
            val prev = if (idx > 0) docs[idx - 1] else null
            val next = if (idx >= 0 && idx < docs.size - 1) docs[idx + 1] else null
            val adapter = PageAdapter(ratios, prev, next)
            pageAdapter = adapter
            b.pages.resetZoom()
            b.pages.adapter = adapter
            val page = if (startPage < 0) ratios.size - 1 else startPage.coerceIn(0, ratios.size - 1)
            scrollToPage(page)
            updateSubtitle(page)
        }
    }

    private fun scrollToPage(page: Int) {
        val adapter = pageAdapter ?: return
        val lm = b.pages.layoutManager as? LinearLayoutManager ?: return
        lm.scrollToPositionWithOffset(adapter.positionOfPage(page.coerceIn(0, adapter.pageCount - 1)), 0)
    }

    private fun currentPosition(): Int {
        val lm = b.pages.layoutManager as? LinearLayoutManager ?: return -1
        if (horizontal) {
            val v = snapHelper.findSnapView(lm) ?: return lm.findFirstVisibleItemPosition()
            return lm.getPosition(v)
        }
        return lm.findFirstVisibleItemPosition()
    }

    private fun currentPage(): Int {
        val adapter = pageAdapter ?: return 0
        return adapter.pageAt(currentPosition()).coerceIn(0, adapter.pageCount - 1)
    }

    private fun updateSubtitle(page: Int) {
        val n = pageAdapter?.pageCount ?: 0
        b.toolbar.subtitle = if (n <= 1) "1 page" else "Page ${page + 1} of $n"
    }

    /** When scrolling stops: update "Page X of N", or open the next/previous document if its card is showing. */
    private fun onSettled() {
        val adapter = pageAdapter ?: return
        val pos = currentPosition()
        if (pos < 0) return
        when (adapter.getItemViewType(pos)) {
            TYPE_NEXT -> if (horizontal) adapter.nextDoc?.let { openDocument(it, 0) }
            TYPE_PREV -> if (horizontal) adapter.prevDoc?.let { openDocument(it, -1) }
            else -> updateSubtitle(adapter.pageAt(pos))
        }
    }

    /** After zooming in, re-render the visible pages at higher resolution so text stays sharp. */
    private fun onZoomSettled(z: Float) {
        val adapter = pageAdapter ?: return
        val target = if (z >= 1.4f) min(z, 2.5f) else 1f
        if (abs(target - adapter.renderScale) < 0.25f) return
        adapter.renderScale = target
        adapter.clearCache()
        val lm = b.pages.layoutManager as? LinearLayoutManager ?: return
        val first = lm.findFirstVisibleItemPosition()
        val last = lm.findLastVisibleItemPosition()
        if (first >= 0 && last >= first) adapter.notifyItemRangeChanged(first, last - first + 1, PAYLOAD_RERENDER)
    }

    class PageVH(val b: ItemPageBinding) : RecyclerView.ViewHolder(b.root) {
        var job: Job? = null
        var boundPos = -1
    }

    class NavVH(val b: ItemDocNavBinding) : RecyclerView.ViewHolder(b.root)

    private inner class PageAdapter(
        private val ratios: List<Float>,
        val prevDoc: File?,
        val nextDoc: File?,
    ) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        var renderScale = 1f
        val pageCount: Int get() = ratios.size
        private val offset = if (prevDoc != null) 1 else 0

        private val cache = object : LruCache<Int, Bitmap>(64 * 1024 * 1024) {
            override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
        }

        fun clearCache() = cache.evictAll()
        fun positionOfPage(page: Int): Int = page + offset
        fun pageAt(position: Int): Int = position - offset

        override fun getItemCount(): Int = ratios.size + offset + (if (nextDoc != null) 1 else 0)

        override fun getItemViewType(position: Int): Int = when {
            prevDoc != null && position == 0 -> TYPE_PREV
            nextDoc != null && position == getItemCount() - 1 -> TYPE_NEXT
            else -> TYPE_PAGE
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val inflater = LayoutInflater.from(parent.context)
            return if (viewType == TYPE_PAGE) PageVH(ItemPageBinding.inflate(inflater, parent, false))
            else NavVH(ItemDocNavBinding.inflate(inflater, parent, false))
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            when (holder) {
                is PageVH -> bindPage(holder, pageAt(position))
                is NavVH -> bindNav(holder, getItemViewType(position))
            }
        }

        private fun bindNav(h: NavVH, type: Int) {
            val lp = h.itemView.layoutParams
            lp.width = ViewGroup.LayoutParams.MATCH_PARENT
            lp.height = if (horizontal) ViewGroup.LayoutParams.MATCH_PARENT else ViewGroup.LayoutParams.WRAP_CONTENT
            h.itemView.layoutParams = lp
            val isNext = type == TYPE_NEXT
            val doc = if (isNext) nextDoc else prevDoc
            h.b.navIcon.setImageResource(if (isNext) R.drawable.ic_chevron_right else R.drawable.ic_chevron_left)
            h.b.navLabel.text = if (isNext) "Next document" else "Previous document"
            h.b.navName.text = doc?.nameWithoutExtension.orEmpty()
            h.b.navHint.text = if (horizontal) "Swipe or tap to open" else "Tap to open"
            h.b.navCard.setOnClickListener { doc?.let { openDocument(it, if (isNext) 0 else -1) } }
        }

        private fun bindPage(h: PageVH, page: Int) {
            h.job?.cancel()
            h.b.pageNumber.text = "${page + 1} / ${ratios.size}"
            val ratio = ratios[page]

            val rootLp = h.itemView.layoutParams
            rootLp.width = ViewGroup.LayoutParams.MATCH_PARENT
            rootLp.height = if (horizontal) ViewGroup.LayoutParams.MATCH_PARENT else ViewGroup.LayoutParams.WRAP_CONTENT
            h.itemView.layoutParams = rootLp

            val padX = h.itemView.paddingLeft + h.itemView.paddingRight
            val padY = h.itemView.paddingTop + h.itemView.paddingBottom
            val availW = (b.pages.width.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels) - padX
            val availH = (b.pages.height.takeIf { it > 0 } ?: resources.displayMetrics.heightPixels) - padY
            // Swipe mode: fit the whole page on screen. Scroll mode: fill the width.
            val pageW = if (horizontal) min(availW.toFloat(), availH / ratio).roundToInt() else availW
            val pageH = (pageW * ratio).roundToInt()
            val lp = h.b.pageImage.layoutParams as FrameLayout.LayoutParams
            lp.width = pageW
            lp.height = pageH
            lp.gravity = if (horizontal) Gravity.CENTER else Gravity.CENTER_HORIZONTAL
            h.b.pageImage.layoutParams = lp

            val samePage = h.boundPos == page
            h.boundPos = page
            val cached = cache.get(page)
            if (cached != null) {
                h.b.pageImage.setImageBitmap(cached)
                return
            }
            // When re-rendering the same page sharper, keep the old image until the new one is ready.
            if (!samePage) h.b.pageImage.setImageDrawable(null)
            val renderWidth = min((pageW * renderScale).roundToInt(), if (renderScale > 1f) 2200 else 1600).coerceAtLeast(1)
            h.job = lifecycleScope.launch {
                val bmp = withContext(renderDispatcher) {
                    runCatching {
                        renderer?.openPage(page)?.use { p -> PdfTools.renderPage(p, renderWidth) }
                    }.getOrNull()
                }
                if (bmp != null && h.boundPos == page) {
                    cache.put(page, bmp)
                    h.b.pageImage.setImageBitmap(bmp)
                }
            }
        }
    }

    companion object {
        const val EXTRA_PATH = "path"
        private const val PAYLOAD_RERENDER = "rerender"
        private const val TYPE_PAGE = 0
        private const val TYPE_PREV = 1
        private const val TYPE_NEXT = 2
    }
}
