package com.zeesh.docscanner

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import java.io.File
import java.io.IOException
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt

/** Colour filters for scanned pages (CamScanner style). */
enum class PageFilter(val label: String) {
    ORIGINAL("Original"),
    ENHANCE("Enhance"),
    GRAYSCALE("Grayscale"),
    BW("Black & White");

    /** Returns a filtered copy, or the same bitmap for [ORIGINAL]. */
    fun apply(src: Bitmap): Bitmap {
        if (this == ORIGINAL) return src
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        paint.colorFilter = ColorMatrixColorFilter(matrix())
        Canvas(out).drawBitmap(src, 0f, 0f, paint)
        return out
    }

    private fun matrix(): ColorMatrix = when (this) {
        ORIGINAL -> ColorMatrix()
        ENHANCE -> contrast(1.35f, 14f).apply { preConcat(ColorMatrix().apply { setSaturation(1.25f) }) }
        GRAYSCALE -> contrast(1.15f, 6f).apply { preConcat(ColorMatrix().apply { setSaturation(0f) }) }
        BW -> {
            // Luminance pushed hard around a threshold -> crisp black text on white paper.
            val k = 5f
            val offset = -k * 140f + 128f
            ColorMatrix(
                floatArrayOf(
                    0.299f * k, 0.587f * k, 0.114f * k, 0f, offset,
                    0.299f * k, 0.587f * k, 0.114f * k, 0f, offset,
                    0.299f * k, 0.587f * k, 0.114f * k, 0f, offset,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        }
    }

    private fun contrast(c: Float, brightness: Float): ColorMatrix {
        val t = (1f - c) * 128f + brightness
        return ColorMatrix(
            floatArrayOf(
                c, 0f, 0f, 0f, t,
                0f, c, 0f, 0f, t,
                0f, 0f, c, 0f, t,
                0f, 0f, 0f, 1f, 0f
            )
        )
    }
}

enum class StampCorner(val label: String) { BOTTOM_LEFT("Bottom left"), BOTTOM_RIGHT("Bottom right") }

/** Text (name, date, time) written in a bottom corner of a page. */
data class Stamp(
    val name: String,
    val date: String?,
    val time: String?,
    val corner: StampCorner,
    /** Text height as a fraction of the page width. */
    val sizeFactor: Float,
    val color: Int,
) {
    fun lines(): List<String> {
        val out = ArrayList<String>()
        if (name.isNotBlank()) out.add(name.trim())
        val dateTime = listOfNotNull(date, time).joinToString("   ")
        if (dateTime.isNotBlank()) out.add(dateTime)
        return out
    }

    companion object {
        const val SMALL = 0.024f
        const val MEDIUM = 0.032f
        const val LARGE = 0.042f
    }
}

object EditImages {

    /** Applies the filter and stamp to [base] (which is recycled if a new bitmap is made). */
    fun render(base: Bitmap, filter: PageFilter, stamp: Stamp?): Bitmap {
        val filtered = filter.apply(base)
        if (filtered !== base) base.recycle()
        if (stamp == null || stamp.lines().isEmpty()) return filtered
        val stamped = drawStamp(filtered, stamp)
        if (stamped !== filtered) filtered.recycle()
        return stamped
    }

    fun decodeRendered(file: File, maxSide: Int, filter: PageFilter, stamp: Stamp?): Bitmap? {
        val base = decode(file, maxSide) ?: return null
        return render(base, filter, stamp)
    }

    private fun drawStamp(src: Bitmap, stamp: Stamp): Bitmap {
        val lines = stamp.lines()
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        val w = out.width.toFloat()
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = stamp.color
            textSize = w * stamp.sizeFactor
            typeface = Typeface.DEFAULT_BOLD
        }
        val fm = textPaint.fontMetrics
        val lineHeight = (fm.descent - fm.ascent) * 1.1f
        val pad = textPaint.textSize * 0.4f
        val margin = w * 0.035f
        val textWidth = lines.maxOf { textPaint.measureText(it) }
        val boxW = textWidth + 2 * pad
        val boxH = lineHeight * (lines.size - 1) + (fm.descent - fm.ascent) + 2 * pad
        val left = if (stamp.corner == StampCorner.BOTTOM_LEFT) margin else w - margin - boxW
        val top = out.height - margin - boxH
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(205, 255, 255, 255) }
        canvas.drawRoundRect(RectF(left, top, left + boxW, top + boxH), pad, pad, bgPaint)
        lines.forEachIndexed { i, line ->
            val x = if (stamp.corner == StampCorner.BOTTOM_LEFT) left + pad
            else left + boxW - pad - textPaint.measureText(line)
            val y = top + pad - fm.ascent + i * lineHeight
            canvas.drawText(line, x, y, textPaint)
        }
        return out
    }

    /** Decodes an image so its longest side is at most [maxSide] pixels. */
    fun decode(file: File, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp: Bitmap = BitmapFactory.decodeFile(file.absolutePath, opts) ?: return null
        val longSide = max(bmp.width, bmp.height)
        if (longSide <= maxSide) return bmp
        val f = maxSide.toFloat() / longSide
        val scaled = Bitmap.createScaledBitmap(
            bmp,
            (bmp.width * f).roundToInt().coerceAtLeast(1),
            (bmp.height * f).roundToInt().coerceAtLeast(1),
            true
        )
        if (scaled !== bmp) bmp.recycle()
        return scaled
    }

    fun decodeFiltered(file: File, maxSide: Int, filter: PageFilter): Bitmap? {
        val base = decode(file, maxSide) ?: return null
        val out = filter.apply(base)
        if (out !== base) base.recycle()
        return out
    }

    fun decodeFull(file: File): Bitmap =
        BitmapFactory.decodeFile(file.absolutePath) ?: throw IOException("Couldn't read the page image")

    fun save(bmp: Bitmap, file: File, quality: Int = 92) {
        file.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, quality, it) }
    }

    fun rotate(src: Bitmap, degrees: Float): Bitmap {
        val m = Matrix()
        m.postRotate(degrees)
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    /**
     * Straightens the quadrilateral [p] (TL, TR, BR, BL as x,y pairs in image pixels)
     * into a flat rectangle, like CamScanner's crop.
     */
    fun perspectiveCrop(src: Bitmap, p: FloatArray): Bitmap {
        fun dist(i: Int, j: Int): Float = hypot(p[2 * j] - p[2 * i], p[2 * j + 1] - p[2 * i + 1])
        var w = max(dist(0, 1), dist(3, 2))
        var h = max(dist(0, 3), dist(1, 2))
        val limit = 4000f
        if (max(w, h) > limit) {
            val s = limit / max(w, h)
            w *= s
            h *= s
        }
        val outW = w.roundToInt().coerceAtLeast(1)
        val outH = h.roundToInt().coerceAtLeast(1)
        val dst = floatArrayOf(0f, 0f, outW.toFloat(), 0f, outW.toFloat(), outH.toFloat(), 0f, outH.toFloat())
        val m = Matrix()
        m.setPolyToPoly(p, 0, dst, 0, 4)
        val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawColor(Color.WHITE)
        canvas.drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        return out
    }
}
