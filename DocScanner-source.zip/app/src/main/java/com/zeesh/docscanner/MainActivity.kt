package com.zeesh.docscanner

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.view.WindowManager
import android.widget.PopupMenu
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.IntentCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import com.zeesh.docscanner.databinding.ActivityMainBinding
import com.zeesh.docscanner.databinding.DialogCompressBinding
import com.zeesh.docscanner.databinding.DialogMergeBinding
import com.zeesh.docscanner.databinding.DialogRenameBinding
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.util.Collections
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var repo: DocRepository
    private lateinit var adapter: DocumentAdapter

    /** When set, the next scan is appended to this document instead of creating a new one. */
    private var appendTarget: File? = null
    /** Document waiting to be written to the location the user picks. */
    private var exportSource: File? = null

    private val pdfMime = arrayOf("application/pdf")

    // ---------- Activity result launchers ----------

    private val scanLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        val target = appendTarget
        appendTarget = null
        if (res.resultCode != RESULT_OK) return@registerForActivityResult
        val pdfUri = GmsDocumentScanningResult.fromActivityResultIntent(res.data)?.pdf?.uri
        if (pdfUri == null) {
            toast("Scan failed, please try again")
            return@registerForActivityResult
        }
        if (target != null && target.exists()) appendPages(target, pdfUri) else saveScan(pdfUri)
    }

    private val pickImages = registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
        if (uris.isNotEmpty()) imagesToPdf(uris)
    }

    private val pickPdfsForMerge = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) prepareExternalMerge(uris)
    }

    private val pickPdfForCompress = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) compressExternal(uri)
    }

    private val pickPdfsForImport = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) importPdfs(uris)
    }

    private val exportLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = exportSource
        exportSource = null
        if (uri != null && src != null) exportTo(src, uri)
    }

    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() = clearSelection()
    }

    // ---------- Lifecycle ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        savedInstanceState?.let { s ->
            appendTarget = s.getString(KEY_APPEND)?.let { File(it) }
            exportSource = s.getString(KEY_EXPORT)?.let { File(it) }
        }

        repo = DocRepository(this)
        adapter = DocumentAdapter(
            lifecycleScope,
            onClick = ::onDocClick,
            onLongClick = ::onDocLongClick,
            onMenu = ::showDocMenu,
        )
        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter

        b.fabScan.setOnClickListener { startScan(null) }
        b.btnImages.setOnClickListener {
            pickImages.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        b.btnImport.setOnClickListener { pickPdfsForImport.launch(pdfMime) }
        b.btnMerge.setOnClickListener { onMergeButton() }
        b.btnCompress.setOnClickListener { onCompressButton() }

        b.toolbar.setNavigationOnClickListener { clearSelection() }
        b.toolbar.setOnMenuItemClickListener { onToolbarItem(it) }
        onBackPressedDispatcher.addCallback(this, backCallback)
        updateToolbar()

        if (savedInstanceState == null) handleSharedIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleSharedIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        appendTarget?.let { outState.putString(KEY_APPEND, it.absolutePath) }
        exportSource?.let { outState.putString(KEY_EXPORT, it.absolutePath) }
    }

    // ---------- List & selection ----------

    private fun refresh() {
        lifecycleScope.launch {
            val infos = withContext(Dispatchers.IO) { repo.loadInfos() }
            adapter.submit(infos)
            b.empty.isVisible = infos.isEmpty()
            b.header.text = if (infos.isEmpty()) getString(R.string.my_documents)
            else getString(R.string.my_documents) + " (${infos.size})"
            if (adapter.selectionMode) updateToolbar()
        }
    }

    private fun updateToolbar() {
        val selecting = adapter.selectionMode
        b.toolbar.menu.clear()
        if (selecting) {
            b.toolbar.title = "${adapter.selectedCount} selected"
            b.toolbar.setNavigationIcon(R.drawable.ic_close)
            b.toolbar.inflateMenu(R.menu.menu_selection)
        } else {
            b.toolbar.title = getString(R.string.app_name)
            b.toolbar.navigationIcon = null
            b.toolbar.inflateMenu(R.menu.menu_main)
        }
        backCallback.isEnabled = selecting
        if (selecting) b.fabScan.hide() else b.fabScan.show()
    }

    private fun clearSelection() {
        adapter.clearSelection()
        updateToolbar()
    }

    private fun onToolbarItem(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_select -> {
                adapter.startSelection(null)
                updateToolbar()
            }
            R.id.action_merge -> mergeSelected()
            R.id.action_share -> FileActions.share(this, adapter.selectedFiles())
            R.id.action_delete -> confirmDelete(adapter.selectedFiles())
            R.id.action_select_all -> {
                adapter.selectAll()
                updateToolbar()
            }
            else -> return false
        }
        return true
    }

    private fun onDocClick(file: File) {
        if (adapter.selectionMode) {
            adapter.toggle(file)
            updateToolbar()
        } else {
            openViewer(file)
        }
    }

    private fun onDocLongClick(file: File) {
        if (adapter.selectionMode) adapter.toggle(file) else adapter.startSelection(file)
        updateToolbar()
    }

    private fun showDocMenu(file: File, anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menuInflater.inflate(R.menu.menu_doc_item, popup.menu)
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.doc_add_pages -> startScan(file)
                R.id.doc_compress -> compressDialog(file, isExternal = false, displayName = file.nameWithoutExtension)
                R.id.doc_share -> FileActions.share(this, listOf(file))
                R.id.doc_export -> {
                    exportSource = file
                    exportLauncher.launch(file.name)
                }
                R.id.doc_open_with -> FileActions.openWith(this, file)
                R.id.doc_rename -> renameDialog(file)
                R.id.doc_delete -> confirmDelete(listOf(file))
            }
            true
        }
        popup.show()
    }

    private fun openViewer(file: File) {
        startActivity(Intent(this, ViewerActivity::class.java).putExtra(ViewerActivity.EXTRA_PATH, file.absolutePath))
    }

    // ---------- Scanning ----------

    private fun startScan(appendTo: File?) {
        val options = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_PDF)
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        GmsDocumentScanning.getClient(options)
            .getStartScanIntent(this)
            .addOnSuccessListener { sender ->
                appendTarget = appendTo
                scanLauncher.launch(IntentSenderRequest.Builder(sender).build())
            }
            .addOnFailureListener { e ->
                MaterialAlertDialogBuilder(this)
                    .setTitle("Scanner not ready")
                    .setMessage(
                        "The document scanner uses Google Play services. The first time, it may need a minute " +
                            "to download — make sure you're online and try again.\n\n(${e.message})"
                    )
                    .setPositiveButton("OK", null)
                    .show()
            }
    }

    private fun saveScan(uri: Uri) {
        runTask("Saving scan…", { repo.importUri(uri, repo.defaultName("Scan")) }) { f ->
            snack("Saved ${f.nameWithoutExtension}", "Rename") { renameDialog(f) }
        }
    }

    private fun appendPages(target: File, uri: Uri) {
        runTask("Adding pages…", {
            val extra = repo.copyToCache(uri, "append_new.pdf")
            val tmp = File(cacheDir, "append_out.pdf")
            PdfTools.merge(this, listOf(target, extra), tmp)
            tmp.copyTo(target, overwrite = true)
            tmp.delete()
            extra.delete()
            target
        }) { f -> snack("Pages added to ${f.nameWithoutExtension}") }
    }

    // ---------- Images → PDF, import, export ----------

    private fun imagesToPdf(uris: List<Uri>) {
        runTask("Creating PDF…", { progress ->
            val out = repo.uniqueFile(repo.defaultName("Images"))
            try {
                PdfTools.imagesToPdf(this, uris, out) { i, n -> progress("Adding image $i of $n…") }
            } catch (e: Exception) {
                out.delete()
                throw e
            }
            out
        }) { f -> snack("Created ${f.nameWithoutExtension}", "Open") { openViewer(f) } }
    }

    private fun importPdfs(uris: List<Uri>) {
        runTask("Importing…", { uris.map { repo.importUri(it, repo.displayName(it)) } }) { files ->
            snack(if (files.size == 1) "Imported ${files[0].nameWithoutExtension}" else "Imported ${files.size} PDFs")
        }
    }

    private fun exportTo(src: File, uri: Uri) {
        runTask("Saving…", {
            val out = contentResolver.openOutputStream(uri) ?: throw IOException("Couldn't write the file")
            out.use { o -> src.inputStream().use { it.copyTo(o) } }
        }) { snack("Saved to your phone") }
    }

    private fun handleSharedIntent(intent: Intent?) {
        intent ?: return
        val uris: List<Uri> = when (intent.action) {
            Intent.ACTION_SEND ->
                listOfNotNull(IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java))
            Intent.ACTION_SEND_MULTIPLE ->
                IntentCompat.getParcelableArrayListExtra(intent, Intent.EXTRA_STREAM, Uri::class.java) ?: emptyList()
            else -> return
        }
        if (uris.isEmpty()) return
        val images = uris.filter { (contentResolver.getType(it) ?: intent.type ?: "").startsWith("image/") }
        val pdfs = uris - images.toSet()
        if (images.isNotEmpty()) imagesToPdf(images) else if (pdfs.isNotEmpty()) importPdfs(pdfs)
    }

    // ---------- Merge ----------

    private fun onMergeButton() {
        if (repo.list().size < 2) {
            pickPdfsForMerge.launch(pdfMime)
            return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Merge PDFs")
            .setItems(arrayOf("Choose from My documents", "Pick PDFs from phone storage")) { _, which ->
                if (which == 0) {
                    adapter.startSelection(null)
                    updateToolbar()
                    snack("Tap documents in the order you want, then tap Merge")
                } else {
                    pickPdfsForMerge.launch(pdfMime)
                }
            }
            .show()
    }

    private fun mergeSelected() {
        val files = adapter.selectedFiles()
        if (files.size < 2) {
            toast("Select at least 2 documents to merge")
            return
        }
        showMergeDialog(files.map { MergeItem(it.nameWithoutExtension, it) })
    }

    private fun prepareExternalMerge(uris: List<Uri>) {
        if (uris.size < 2) {
            toast("Pick at least 2 PDFs to merge")
            return
        }
        runTask("Preparing…", {
            uris.mapIndexed { i, u -> MergeItem(repo.displayName(u), repo.copyToCache(u, "merge_in_$i.pdf")) }
        }) { items -> showMergeDialog(items) }
    }

    private fun showMergeDialog(items: List<MergeItem>) {
        val db = DialogMergeBinding.inflate(layoutInflater)
        val list = items.toMutableList()
        lateinit var touchHelper: ItemTouchHelper
        val mergeAdapter = MergeAdapter(list) { vh -> touchHelper.startDrag(vh) }
        db.mergeList.layoutManager = LinearLayoutManager(this)
        db.mergeList.adapter = mergeAdapter
        touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0) {
            override fun onMove(rv: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
                val from = vh.bindingAdapterPosition
                val to = target.bindingAdapterPosition
                if (from < 0 || to < 0) return false
                Collections.swap(list, from, to)
                mergeAdapter.notifyItemMoved(from, to)
                return true
            }

            override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) {}

            override fun clearView(rv: RecyclerView, vh: RecyclerView.ViewHolder) {
                super.clearView(rv, vh)
                rv.post { mergeAdapter.notifyItemRangeChanged(0, list.size) }
            }
        })
        touchHelper.attachToRecyclerView(db.mergeList)
        db.nameInput.setText(repo.defaultName("Merged"))

        MaterialAlertDialogBuilder(this)
            .setTitle("Merge ${list.size} PDFs")
            .setView(db.root)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Merge") { _, _ ->
                doMerge(list.map { it.file }, db.nameInput.text?.toString().orEmpty())
            }
            .show()
    }

    private fun doMerge(files: List<File>, name: String) {
        runTask("Merging…", {
            val out = repo.uniqueFile(name.ifBlank { repo.defaultName("Merged") })
            try {
                PdfTools.merge(this, files, out)
            } catch (e: Exception) {
                out.delete()
                throw e
            }
            out
        }) { f ->
            clearSelection()
            snack("Merged into ${f.nameWithoutExtension}", "Open") { openViewer(f) }
        }
    }

    // ---------- Compress (reduce file size) ----------

    private fun onCompressButton() {
        val docs = repo.list()
        if (docs.isEmpty()) {
            pickPdfForCompress.launch(pdfMime)
            return
        }
        val names = listOf("Browse phone storage…") + docs.map { "${it.nameWithoutExtension}  (${formatSize(it.length())})" }
        MaterialAlertDialogBuilder(this)
            .setTitle("Choose a PDF to shrink")
            .setItems(names.toTypedArray()) { _, which ->
                if (which == 0) pickPdfForCompress.launch(pdfMime)
                else compressDialog(docs[which - 1], isExternal = false, displayName = docs[which - 1].nameWithoutExtension)
            }
            .show()
    }

    private fun compressExternal(uri: Uri) {
        runTask("Opening…", {
            Pair(repo.displayName(uri), repo.copyToCache(uri, "compress_in.pdf"))
        }) { (name, file) -> compressDialog(file, isExternal = true, displayName = name) }
    }

    private fun compressDialog(file: File, isExternal: Boolean, displayName: String) {
        val db = DialogCompressBinding.inflate(layoutInflater)
        db.compressInfo.text = "Current size: ${formatSize(file.length())}"
        db.levelMedium.isChecked = true
        MaterialAlertDialogBuilder(this)
            .setTitle("Reduce file size")
            .setView(db.root)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Compress") { _, _ ->
                val level = when (db.levelGroup.checkedRadioButtonId) {
                    R.id.levelSmall -> PdfTools.Level.SMALL
                    R.id.levelHigh -> PdfTools.Level.HIGH
                    else -> PdfTools.Level.MEDIUM
                }
                doCompress(file, isExternal, displayName, level, db.grayscale.isChecked)
            }
            .show()
    }

    private fun doCompress(file: File, isExternal: Boolean, displayName: String, level: PdfTools.Level, grayscale: Boolean) {
        val before = file.length()
        runTask("Compressing…", { progress ->
            val out = repo.uniqueFile("$displayName (compressed)")
            try {
                PdfTools.compress(file, out, level, grayscale) { i, n -> progress("Compressing page $i of $n…") }
            } catch (e: Exception) {
                out.delete()
                throw e
            }
            out
        }) { out ->
            val after = out.length()
            if (after >= before) {
                out.delete()
                refresh()
                MaterialAlertDialogBuilder(this)
                    .setTitle("Already optimized")
                    .setMessage(
                        "This PDF is already small (${formatSize(before)}). " +
                            "Try \"Smallest size\" or Grayscale for a smaller file."
                    )
                    .setPositiveButton("OK", null)
                    .show()
            } else {
                val pct = ((1 - after.toDouble() / before) * 100).roundToInt()
                val dialog = MaterialAlertDialogBuilder(this)
                    .setTitle("Done — $pct% smaller")
                    .setMessage("${formatSize(before)}  →  ${formatSize(after)}\n\nSaved as \"${out.nameWithoutExtension}\".")
                if (isExternal) {
                    dialog.setPositiveButton("Open") { _, _ -> openViewer(out) }
                        .setNegativeButton("Close", null)
                } else {
                    dialog.setPositiveButton("Replace original") { _, _ -> replaceWithCompressed(file, out) }
                        .setNegativeButton("Keep both", null)
                }
                dialog.show()
            }
        }
    }

    private fun replaceWithCompressed(original: File, compressed: File) {
        val target = File(original.absolutePath)
        if (original.delete() && compressed.renameTo(target)) snack("Original replaced with smaller version")
        else toast("Couldn't replace the original")
        refresh()
    }

    // ---------- Rename / delete ----------

    private fun renameDialog(file: File) {
        val db = DialogRenameBinding.inflate(layoutInflater)
        db.nameInput.setText(file.nameWithoutExtension)
        db.nameInput.selectAll()
        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle("Rename")
            .setView(db.root)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                if (repo.rename(file, db.nameInput.text?.toString().orEmpty()) == null) toast("Couldn't rename")
                refresh()
            }
            .create()
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        dialog.show()
        db.nameInput.requestFocus()
    }

    private fun confirmDelete(files: List<File>) {
        if (files.isEmpty()) return
        val title = if (files.size == 1) "Delete \"${files[0].nameWithoutExtension}\"?" else "Delete ${files.size} documents?"
        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setMessage("This can't be undone.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                files.forEach { it.delete() }
                if (adapter.selectionMode) clearSelection()
                refresh()
            }
            .show()
    }

    // ---------- Helpers ----------

    /** Runs [work] off the main thread behind a progress overlay, then calls [done] with the result. */
    private fun <T> runTask(message: String, work: suspend (progress: (String) -> Unit) -> T, done: (T) -> Unit) {
        b.progressText.text = message
        b.progressOverlay.isVisible = true
        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    work { msg -> runOnUiThread { b.progressText.text = msg } }
                }
            }
            if (result.exceptionOrNull() is CancellationException) return@launch
            b.progressOverlay.isVisible = false
            refresh()
            result.onSuccess(done).onFailure { showError(it) }
        }
    }

    private fun showError(e: Throwable) {
        val msg = when (e) {
            is OutOfMemoryError -> "Not enough memory for this file. Try fewer pages or a smaller size option."
            is SecurityException -> "This PDF is password protected and can't be opened."
            else -> e.message ?: e.javaClass.simpleName
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Something went wrong")
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun snack(msg: String, action: String? = null, onAction: (() -> Unit)? = null) {
        val s = Snackbar.make(b.root, msg, Snackbar.LENGTH_LONG)
        if (action != null && onAction != null) s.setAction(action) { onAction() }
        s.show()
    }

    companion object {
        private const val KEY_APPEND = "append_target"
        private const val KEY_EXPORT = "export_source"
    }
}
