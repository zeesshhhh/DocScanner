package com.zeesh.docscanner

import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.util.LruCache
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.PopupMenu
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import com.zeesh.docscanner.databinding.ActivityEditorBinding
import com.zeesh.docscanner.databinding.ItemEditPageBinding
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.util.Collections
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** One page being edited: its current image plus a colour filter applied on save. */
class EditPage(var file: File, var filter: PageFilter = PageFilter.ORIGINAL) {
    val id: Long = nextId++
    var version: Int = 0
    val key: String get() = "$id:$version:${filter.name}"

    companion object {
        private var nextId = 1L
    }
}

/**
 * Page editor: reorder (drag or move up/down), crop, rotate, filters,
 * replace (rescan or image), delete and add pages. Saves back into the PDF.
 */
class EditorActivity : AppCompatActivity() {

    private enum class Mode { GRID, PAGE, CROP }
    private enum class Pending { NONE, ADD, REPLACE }

    private lateinit var b: ActivityEditorBinding
    private lateinit var source: File
    private lateinit var sessionDir: File
    private lateinit var gridAdapter: PageGridAdapter
    private lateinit var touchHelper: ItemTouchHelper

    private val pages = mutableListOf<EditPage>()
    private var mode = Mode.GRID
    private var current = 0
    private var modified = false
    private var loaded = false
    private var pending = Pending.NONE
    private var suppressChips = false
    private val chipIds = HashMap<PageFilter, Int>()
    private var cropPreviewWidth = 1

    private val thumbs = object : LruCache<String, Bitmap>(32 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val previewMaxSide: Int by lazy {
        val dm = resources.displayMetrics
        min(max(dm.widthPixels, dm.heightPixels), 2000)
    }

    // ---------- Pickers ----------

    private val scanLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        val what = pending
        pending = Pending.NONE
        if (res.resultCode != RESULT_OK) return@registerForActivityResult
        val uris: List<Uri> = GmsDocumentScanningResult.fromActivityResultIntent(res.data)
            ?.pages?.map { it.imageUri } ?: emptyList()
        if (uris.isEmpty()) return@registerForActivityResult
        if (what == Pending.REPLACE) replaceCurrent(uris[0]) else addImages(uris)
    }

    private val pickImages = registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
        if (uris.isNotEmpty()) addImages(uris)
    }

    private val pickOneImage = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) replaceCurrent(uri)
    }

    private val pickPdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) addPdfPages(uri)
    }

    // ---------- Lifecycle ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        b = ActivityEditorBinding.inflate(layoutInflater)
        setContentView(b.root)
        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        val path = intent.getStringExtra(EXTRA_PATH)
        if (path == null) {
            finish()
            return
        }
        source = File(path)
        // Each editor gets its own temp folder; leftovers older than a day (e.g. after a crash) are cleared.
        val now = System.currentTimeMillis()
        cacheDir.listFiles { f -> f.isDirectory && f.name.startsWith("edit_") && now - f.lastModified() > 86_400_000L }
            ?.forEach { it.deleteRecursively() }
        sessionDir = File(cacheDir, "edit_$now")
        sessionDir.mkdirs()

        gridAdapter = PageGridAdapter(pages, ::loadThumb, ::openPage, ::showPageMenu)
        val span = if (resources.configuration.screenWidthDp >= 600) 4 else 2
        b.grid.layoutManager = GridLayoutManager(this, span)
        b.grid.adapter = gridAdapter
        touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0
        ) {
            override fun onMove(rv: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
                val from = vh.bindingAdapterPosition
                val to = target.bindingAdapterPosition
                if (from < 0 || to < 0) return false
                Collections.swap(pages, from, to)
                gridAdapter.notifyItemMoved(from, to)
                modified = true
                return true
            }

            override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) {}

            override fun clearView(rv: RecyclerView, vh: RecyclerView.ViewHolder) {
                super.clearView(rv, vh)
                rv.post { gridAdapter.notifyItemRangeChanged(0, pages.size) }
            }
        })
        touchHelper.attachToRecyclerView(b.grid)

        for (f in PageFilter.entries) {
            val chip = layoutInflater.inflate(R.layout.chip_filter, b.filterGroup, false) as Chip
            chip.id = View.generateViewId()
            chip.text = f.label
            chip.tag = f
            b.filterGroup.addView(chip)
            chipIds[f] = chip.id
        }
        b.filterGroup.setOnCheckedStateChangeListener { group, checkedIds ->
            if (suppressChips || checkedIds.isEmpty()) return@setOnCheckedStateChangeListener
            val f = group.findViewById<Chip>(checkedIds[0])?.tag as? PageFilter
                ?: return@setOnCheckedStateChangeListener
            setFilter(current, f)
        }

        b.btnCrop.setOnClickListener { startCrop() }
        b.btnRotate.setOnClickListener { rotateCurrent() }
        b.btnReplace.setOnClickListener { chooseReplaceSource(current) }
        b.btnDeletePage.setOnClickListener { confirmDeletePage(current) }
        b.btnMoveUp.setOnClickListener { movePage(current, current - 1) }
        b.btnMoveDown.setOnClickListener { movePage(current, current + 1) }
        b.btnCropReset.setOnClickListener { b.cropView.resetPoints() }
        b.btnCropCancel.setOnClickListener { setMode(Mode.PAGE) }
        b.btnCropApply.setOnClickListener { applyCrop() }

        b.toolbar.setNavigationOnClickListener { handleBack() }
        b.toolbar.setOnMenuItemClickListener { onMenu(it) }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = handleBack()
        })

        setMode(Mode.GRID)
        loadDocument()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::sessionDir.isInitialized) sessionDir.deleteRecursively()
    }

    // ---------- Loading & thumbnails ----------

    private fun loadDocument() {
        runWork("Opening pages…", { progress ->
            PdfTools.renderToImages(source, sessionDir, 2200) { i, n -> progress("Opening page $i of $n…") }
        }, finishOnError = true) { files ->
            if (files.isEmpty()) {
                toast("This PDF has no pages")
                finish()
            } else {
                pages.clear()
                pages.addAll(files.map { EditPage(it) })
                loaded = true
                gridAdapter.notifyItemRangeInserted(0, pages.size)
                updateToolbar()
            }
        }
    }

    private fun loadThumb(page: EditPage, view: ImageView) {
        val key = page.key
        view.tag = key
        val cached = thumbs.get(key)
        if (cached != null) {
            view.setImageBitmap(cached)
            return
        }
        view.setImageDrawable(null)
        val file = page.file
        val filter = page.filter
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                runCatching { EditImages.decodeFiltered(file, 520, filter) }.getOrNull()
            }
            if (bmp != null) {
                thumbs.put(key, bmp)
                if (view.tag == key) view.setImageBitmap(bmp)
            }
        }
    }

    // ---------- Modes ----------

    private fun setMode(m: Mode) {
        mode = m
        b.gridMode.isVisible = m == Mode.GRID
        b.pageMode.isVisible = m == Mode.PAGE
        b.cropMode.isVisible = m == Mode.CROP
        updateToolbar()
    }

    private fun updateToolbar() {
        val menu = b.toolbar.menu
        menu.clear()
        when (mode) {
            Mode.GRID -> {
                b.toolbar.title = source.nameWithoutExtension
                b.toolbar.subtitle = if (pages.size == 1) "1 page" else "${pages.size} pages"
                b.toolbar.inflateMenu(R.menu.menu_editor)
            }
            Mode.PAGE -> {
                b.toolbar.title = "Page ${current + 1} of ${pages.size}"
                b.toolbar.subtitle = null
                b.toolbar.inflateMenu(R.menu.menu_editor_page)
                menu.findItem(R.id.action_prev)?.isEnabled = current > 0
                menu.findItem(R.id.action_next)?.isEnabled = current < pages.size - 1
            }
            Mode.CROP -> {
                b.toolbar.title = "Crop page ${current + 1}"
                b.toolbar.subtitle = "Drag the 4 corners to the page edges"
            }
        }
    }

    private fun onMenu(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_save -> save(asCopy = false)
            R.id.action_save_copy -> save(asCopy = true)
            R.id.action_add_pages -> chooseAddSource()
            R.id.action_filter_all -> chooseFilterForAll()
            R.id.action_prev -> if (current > 0) {
                current--
                showCurrentPage()
            }
            R.id.action_next -> if (current < pages.size - 1) {
                current++
                showCurrentPage()
            }
            else -> return false
        }
        return true
    }

    private fun handleBack() {
        if (b.progressOverlay.isVisible) return
        when (mode) {
            Mode.CROP -> setMode(Mode.PAGE)
            Mode.PAGE -> {
                setMode(Mode.GRID)
                b.grid.scrollToPosition(current)
            }
            Mode.GRID -> if (modified) {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Save changes?")
                    .setMessage("You have unsaved edits to this document.")
                    .setPositiveButton("Save") { _, _ -> save(asCopy = false) }
                    .setNegativeButton("Discard") { _, _ -> finish() }
                    .setNeutralButton("Keep editing", null)
                    .show()
            } else {
                finish()
            }
        }
    }

    // ---------- Single page ----------

    private fun openPage(index: Int) {
        if (index !in pages.indices) return
        current = index
        setMode(Mode.PAGE)
        showCurrentPage()
    }

    private fun showCurrentPage() {
        val page = pages.getOrNull(current) ?: return
        suppressChips = true
        chipIds[page.filter]?.let { b.filterGroup.check(it) }
        suppressChips = false
        b.btnMoveUp.isEnabled = current > 0
        b.btnMoveDown.isEnabled = current < pages.size - 1
        updateToolbar()
        loadPreview()
    }

    private fun loadPreview() {
        val page = pages.getOrNull(current) ?: return
        val key = page.key
        val file = page.file
        val filter = page.filter
        b.pageImage.tag = key
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                runCatching { EditImages.decodeFiltered(file, previewMaxSide, filter) }.getOrNull()
            }
            if (bmp != null && b.pageImage.tag == key) b.pageImage.setImageBitmap(bmp)
        }
    }

    private fun setFilter(index: Int, f: PageFilter) {
        val page = pages.getOrNull(index) ?: return
        if (page.filter == f) return
        page.filter = f
        modified = true
        gridAdapter.notifyItemChanged(index)
        if (mode == Mode.PAGE && index == current) loadPreview()
    }

    private fun chooseFilterForAll() {
        val names = PageFilter.entries.map { it.label }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Filter for all pages")
            .setItems(names) { _, which ->
                val f = PageFilter.entries[which]
                pages.forEach { it.filter = f }
                modified = true
                gridAdapter.notifyItemRangeChanged(0, pages.size)
            }
            .show()
    }

    private fun newImageFile(): File = File(sessionDir, "img_${System.nanoTime()}.jpg")

    private fun updatePageImage(page: EditPage, file: File) {
        page.file = file
        page.version++
        modified = true
        val idx = pages.indexOf(page)
        if (idx >= 0) gridAdapter.notifyItemChanged(idx)
        if (mode == Mode.PAGE && pages.getOrNull(current) === page) showCurrentPage()
    }

    private fun rotateCurrent() {
        val page = pages.getOrNull(current) ?: return
        val src = page.file
        runWork("Rotating…", {
            val full = EditImages.decodeFull(src)
            val rotated = EditImages.rotate(full, 90f)
            if (rotated !== full) full.recycle()
            val out = newImageFile()
            EditImages.save(rotated, out)
            rotated.recycle()
            out
        }) { out -> updatePageImage(page, out) }
    }

    private fun startCrop() {
        val page = pages.getOrNull(current) ?: return
        val file = page.file
        runWork("Loading…", {
            EditImages.decode(file, previewMaxSide) ?: throw IOException("Couldn't read the page image")
        }) { bmp ->
            cropPreviewWidth = bmp.width
            b.cropView.setImage(bmp)
            setMode(Mode.CROP)
        }
    }

    private fun applyCrop() {
        val page = pages.getOrNull(current) ?: return
        val pts = b.cropView.points()
        val previewW = cropPreviewWidth
        val src = page.file
        runWork("Cropping…", {
            val full = EditImages.decodeFull(src)
            val f = full.width.toFloat() / previewW
            for (i in pts.indices) pts[i] *= f
            val cropped = EditImages.perspectiveCrop(full, pts)
            full.recycle()
            val out = newImageFile()
            EditImages.save(cropped, out)
            cropped.recycle()
            out
        }) { out ->
            setMode(Mode.PAGE)
            updatePageImage(page, out)
        }
    }

    // ---------- Move / delete / replace / add ----------

    private fun movePage(from: Int, to: Int) {
        if (from !in pages.indices || to !in pages.indices || from == to) return
        val p = pages.removeAt(from)
        pages.add(to, p)
        modified = true
        gridAdapter.notifyItemMoved(from, to)
        gridAdapter.notifyItemRangeChanged(min(from, to), abs(from - to) + 1)
        if (mode == Mode.PAGE && current == from) {
            current = to
            showCurrentPage()
        }
        toast("Moved to position ${to + 1}")
    }

    private fun confirmDeletePage(index: Int) {
        if (index !in pages.indices) return
        if (pages.size == 1) {
            MaterialAlertDialogBuilder(this)
                .setTitle("Can't delete the only page")
                .setMessage("A document needs at least one page. To remove the whole document, delete it from the main screen.")
                .setPositiveButton("OK", null)
                .show()
            return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete page ${index + 1}?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                pages.removeAt(index)
                modified = true
                gridAdapter.notifyItemRemoved(index)
                gridAdapter.notifyItemRangeChanged(index, pages.size - index)
                if (mode == Mode.PAGE) {
                    if (current >= pages.size) current = pages.size - 1
                    showCurrentPage()
                } else {
                    updateToolbar()
                }
            }
            .show()
    }

    private fun chooseReplaceSource(index: Int) {
        if (index !in pages.indices) return
        current = index
        MaterialAlertDialogBuilder(this)
            .setTitle("Replace page ${index + 1} with…")
            .setItems(arrayOf("A new scan (camera)", "An image from phone")) { _, which ->
                if (which == 0) startScan(Pending.REPLACE)
                else pickOneImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }
            .show()
    }

    private fun replaceCurrent(uri: Uri) {
        val page = pages.getOrNull(current) ?: return
        runWork("Replacing page…", { importImage(uri) }) { out ->
            page.filter = PageFilter.ORIGINAL
            updatePageImage(page, out)
            toast("Page ${pages.indexOf(page) + 1} replaced")
        }
    }

    private fun chooseAddSource() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Add pages")
            .setItems(arrayOf("Scan with camera", "Images from phone", "Pages from another PDF")) { _, which ->
                when (which) {
                    0 -> startScan(Pending.ADD)
                    1 -> pickImages.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    else -> pickPdf.launch(arrayOf("application/pdf"))
                }
            }
            .show()
    }

    private fun startScan(what: Pending) {
        val builder = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
        if (what == Pending.REPLACE) builder.setPageLimit(1)
        GmsDocumentScanning.getClient(builder.build())
            .getStartScanIntent(this)
            .addOnSuccessListener { sender ->
                pending = what
                scanLauncher.launch(IntentSenderRequest.Builder(sender).build())
            }
            .addOnFailureListener { e -> showError(e) }
    }

    private fun importImage(uri: Uri): File {
        val bmp = PdfTools.decodeImage(this, uri, 2400) ?: throw IOException("Couldn't read that image")
        val out = newImageFile()
        EditImages.save(bmp, out)
        bmp.recycle()
        return out
    }

    private fun addImages(uris: List<Uri>) {
        runWork("Adding pages…", { progress ->
            uris.mapIndexed { i, u ->
                progress("Adding page ${i + 1} of ${uris.size}…")
                importImage(u)
            }
        }) { files -> appendPages(files) }
    }

    private fun addPdfPages(uri: Uri) {
        runWork("Adding pages…", { progress ->
            val tmp = File(sessionDir, "add_${System.nanoTime()}.pdf")
            val input = contentResolver.openInputStream(uri) ?: throw IOException("Couldn't open that PDF")
            input.use { inp -> tmp.outputStream().use { inp.copyTo(it) } }
            try {
                PdfTools.renderToImages(tmp, sessionDir, 2200) { i, n -> progress("Adding page $i of $n…") }
            } finally {
                tmp.delete()
            }
        }) { files -> appendPages(files) }
    }

    private fun appendPages(files: List<File>) {
        if (files.isEmpty()) return
        val start = pages.size
        pages.addAll(files.map { EditPage(it) })
        modified = true
        gridAdapter.notifyItemRangeInserted(start, files.size)
        setMode(Mode.GRID)
        b.grid.scrollToPosition(pages.size - 1)
        toast(if (files.size == 1) "1 page added" else "${files.size} pages added")
    }

    private fun showPageMenu(index: Int, anchor: View) {
        val popup = PopupMenu(this, anchor)
        val m = popup.menu
        m.add(0, MENU_EDIT, 0, "Edit page")
        m.add(0, MENU_UP, 1, "Move up").isEnabled = index > 0
        m.add(0, MENU_DOWN, 2, "Move down").isEnabled = index < pages.size - 1
        m.add(0, MENU_REPLACE, 3, "Replace page")
        m.add(0, MENU_DELETE, 4, "Delete page")
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                MENU_EDIT -> openPage(index)
                MENU_UP -> movePage(index, index - 1)
                MENU_DOWN -> movePage(index, index + 1)
                MENU_REPLACE -> chooseReplaceSource(index)
                MENU_DELETE -> confirmDeletePage(index)
            }
            true
        }
        popup.show()
    }

    // ---------- Save ----------

    private fun save(asCopy: Boolean) {
        if (!loaded || pages.isEmpty()) return
        if (!modified && !asCopy) {
            toast("No changes to save")
            finish()
            return
        }
        val snapshot = pages.map { it.file to it.filter }
        val repo = DocRepository(this)
        runWork("Saving…", { progress ->
            val tmp = File(sessionDir, "out_${System.nanoTime()}.pdf")
            PdfTools.bitmapsToPdf(snapshot.size, tmp, 88, { i ->
                val (file, filter) = snapshot[i]
                val base = EditImages.decodeFull(file)
                val out = filter.apply(base)
                if (out !== base) base.recycle()
                out
            }) { i, n -> progress("Saving page $i of $n…") }
            val target = if (asCopy) repo.uniqueFile(source.nameWithoutExtension + " (edited)") else source
            tmp.copyTo(target, overwrite = true)
            tmp.delete()
            target
        }) { target ->
            RecentStore(this).touch(target)
            modified = false
            setResult(RESULT_OK)
            toast(if (asCopy) "Saved as \"${target.nameWithoutExtension}\"" else "Changes saved")
            finish()
        }
    }

    // ---------- Helpers ----------

    private fun <T> runWork(
        message: String,
        work: suspend (progress: (String) -> Unit) -> T,
        finishOnError: Boolean = false,
        done: (T) -> Unit
    ) {
        b.progressText.text = message
        b.progressOverlay.isVisible = true
        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    work { msg -> runOnUiThread { b.progressText.text = msg } }
                }
            }
            if (result.exceptionOrNull() is CancellationException) return@launch
            b.progressOverlay.isVisible = false
            result.onSuccess(done).onFailure { showError(it, finishOnError) }
        }
    }

    private fun showError(e: Throwable, finishAfter: Boolean = false) {
        val msg = when (e) {
            is OutOfMemoryError -> "Not enough memory for this. Try a document with fewer pages."
            is SecurityException -> "This PDF is password protected and can't be edited."
            else -> e.message ?: e.javaClass.simpleName
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Something went wrong")
            .setMessage(msg)
            .setPositiveButton("OK") { _, _ -> if (finishAfter) finish() }
            .setOnCancelListener { if (finishAfter) finish() }
            .show()
    }

    companion object {
        const val EXTRA_PATH = "path"
        private const val MENU_EDIT = 1
        private const val MENU_UP = 2
        private const val MENU_DOWN = 3
        private const val MENU_REPLACE = 4
        private const val MENU_DELETE = 5
    }
}

class PageGridAdapter(
    private val pages: List<EditPage>,
    private val loadThumb: (EditPage, ImageView) -> Unit,
    private val onClick: (Int) -> Unit,
    private val onMenu: (Int, View) -> Unit,
) : RecyclerView.Adapter<PageGridAdapter.VH>() {

    class VH(val b: ItemEditPageBinding) : RecyclerView.ViewHolder(b.root)

    override fun getItemCount(): Int = pages.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val h = VH(ItemEditPageBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        h.b.card.setOnClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(p)
        }
        h.b.more.setOnClickListener { v ->
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onMenu(p, v)
        }
        return h
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val page = pages[position]
        h.b.pageNum.text = (position + 1).toString()
        h.b.filterTag.isVisible = page.filter != PageFilter.ORIGINAL
        h.b.filterTag.text = page.filter.label
        loadThumb(page, h.b.thumb)
    }
}
