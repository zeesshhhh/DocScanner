package com.zeesh.docscanner

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.min

/** Shows an image with 4 draggable corners for a perspective (4-point) crop. */
class CropView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    private var bitmap: Bitmap? = null
    private val pts = FloatArray(8) // TL, TR, BR, BL in bitmap pixels
    private val drawMatrix = Matrix()
    private var scale = 1f
    private var offX = 0f
    private var offY = 0f
    private var active = -1

    private val density = resources.displayMetrics.density
    private val accent = Color.rgb(76, 141, 246)
    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dimPaint = Paint().apply { color = Color.argb(140, 0, 0, 0) }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * density
        color = accent
    }
    private val handleFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = accent
    }
    private val handleRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
        color = Color.WHITE
    }
    private val dimPath = Path()
    private val outline = Path()

    fun setImage(bmp: Bitmap) {
        bitmap = bmp
        computeTransform()
        resetPoints()
    }

    /** Selects the whole image. */
    fun resetPoints() {
        val b = bitmap ?: return
        val w = b.width.toFloat()
        val h = b.height.toFloat()
        val values = floatArrayOf(0f, 0f, w, 0f, w, h, 0f, h)
        values.copyInto(pts)
        invalidate()
    }

    fun points(): FloatArray = pts.copyOf()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        computeTransform()
    }

    private fun computeTransform() {
        val b = bitmap ?: return
        if (width == 0 || height == 0) return
        val pad = 24f * density
        scale = min((width - 2 * pad) / b.width, (height - 2 * pad) / b.height)
        offX = (width - b.width * scale) / 2f
        offY = (height - b.height * scale) / 2f
        drawMatrix.setScale(scale, scale)
        drawMatrix.postTranslate(offX, offY)
        invalidate()
    }

    private fun vx(i: Int): Float = offX + pts[2 * i] * scale
    private fun vy(i: Int): Float = offY + pts[2 * i + 1] * scale

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val b = bitmap ?: return
        canvas.drawBitmap(b, drawMatrix, bitmapPaint)

        outline.reset()
        outline.moveTo(vx(0), vy(0))
        for (i in 1..3) outline.lineTo(vx(i), vy(i))
        outline.close()

        dimPath.reset()
        dimPath.fillType = Path.FillType.EVEN_ODD
        dimPath.addRect(offX, offY, offX + b.width * scale, offY + b.height * scale, Path.Direction.CW)
        dimPath.addPath(outline)
        canvas.drawPath(dimPath, dimPaint)
        canvas.drawPath(outline, linePaint)

        val r = 11f * density
        for (i in 0..3) {
            canvas.drawCircle(vx(i), vy(i), r, handleFill)
            canvas.drawCircle(vx(i), vy(i), r, handleRing)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        val b = bitmap ?: return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                active = -1
                val touchRadius = 44f * density
                var best = touchRadius * touchRadius
                for (i in 0..3) {
                    val dx = event.x - vx(i)
                    val dy = event.y - vy(i)
                    val d = dx * dx + dy * dy
                    if (d < best) {
                        best = d
                        active = i
                    }
                }
                if (active >= 0) parent?.requestDisallowInterceptTouchEvent(true)
                return active >= 0
            }
            MotionEvent.ACTION_MOVE -> {
                if (active < 0) return false
                pts[2 * active] = ((event.x - offX) / scale).coerceIn(0f, b.width.toFloat())
                pts[2 * active + 1] = ((event.y - offY) / scale).coerceIn(0f, b.height.toFloat())
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                active = -1
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}
