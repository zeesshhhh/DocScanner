package com.zeesh.docscanner

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.VelocityTracker
import android.widget.FrameLayout
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs
import kotlin.math.roundToInt

private const val MAX_ZOOM = 4f
private const val DOUBLE_TAP_ZOOM = 2.5f

/**
 * A vertical page list you can pinch to zoom (2 fingers), pan with one finger
 * when zoomed, and double-tap to zoom in/out.
 */
class ZoomRecyclerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : RecyclerView(context, attrs) {

    /** Called when a zoom gesture finishes, with the new zoom level. */
    var onZoomSettled: ((Float) -> Unit)? = null

    var zoom = 1f
        private set
    private var tx = 0f
    private var ty = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var activeId = -1
    private var takenOver = false
    private var scrollRemainder = 0f
    private var velocity: VelocityTracker? = null

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            zoomTo(zoom * detector.scaleFactor, detector.focusX, detector.focusY)
            return true
        }

        override fun onScaleEnd(detector: ScaleGestureDetector) {
            onZoomSettled?.invoke(zoom)
        }
    })

    private val tapDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            zoomTo(if (zoom > 1.05f) 1f else DOUBLE_TAP_ZOOM, e.x, e.y)
            onZoomSettled?.invoke(zoom)
            return true
        }
    })

    fun resetZoom() {
        zoom = 1f
        tx = 0f
        ty = 0f
        invalidate()
    }

    private fun zoomTo(target: Float, fx: Float, fy: Float) {
        val newZoom = target.coerceIn(1f, MAX_ZOOM)
        val f = newZoom / zoom
        tx = fx - (fx - tx) * f
        ty = fy - (fy - ty) * f
        zoom = newZoom
        clamp()
        invalidate()
    }

    private fun clamp() {
        if (zoom <= 1f) {
            zoom = 1f
            tx = 0f
            ty = 0f
            return
        }
        tx = tx.coerceIn(width - width * zoom, 0f)
        ty = ty.coerceIn(height - height * zoom, 0f)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        clamp()
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        if (e.pointerCount > 1 || zoom > 1f) return true
        return super.onInterceptTouchEvent(e)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(e)
        tapDetector.onTouchEvent(e)

        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            takenOver = zoom > 1f
            scrollRemainder = 0f
            velocity?.recycle()
            velocity = VelocityTracker.obtain()
            if (takenOver) stopScroll()
        }
        if (!takenOver && (e.pointerCount > 1 || scaleDetector.isInProgress)) {
            // A pinch started: stop the list's own scrolling and handle it here.
            takenOver = true
            val cancel = MotionEvent.obtain(e)
            cancel.action = MotionEvent.ACTION_CANCEL
            super.onTouchEvent(cancel)
            cancel.recycle()
        }
        if (!takenOver) return super.onTouchEvent(e)

        velocity?.addMovement(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                activeId = e.getPointerId(0)
                lastX = e.x
                lastY = e.y
            }
            MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_POINTER_UP -> {
                val leaving = if (e.actionMasked == MotionEvent.ACTION_POINTER_UP) e.actionIndex else -1
                for (i in 0 until e.pointerCount) {
                    if (i != leaving) {
                        activeId = e.getPointerId(i)
                        lastX = e.getX(i)
                        lastY = e.getY(i)
                        break
                    }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val idx = e.findPointerIndex(activeId)
                if (idx >= 0) {
                    val x = e.getX(idx)
                    val y = e.getY(idx)
                    val dx = x - lastX
                    val dy = y - lastY
                    lastX = x
                    lastY = y
                    if (!scaleDetector.isInProgress && zoom > 1f) panBy(dx, dy)
                }
            }
            MotionEvent.ACTION_UP -> {
                val vt = velocity
                if (vt != null && zoom > 1f && !scaleDetector.isInProgress) {
                    vt.computeCurrentVelocity(1000)
                    fling(0, (-vt.yVelocity / zoom).roundToInt())
                }
                velocity?.recycle()
                velocity = null
            }
            MotionEvent.ACTION_CANCEL -> {
                velocity?.recycle()
                velocity = null
            }
        }
        return true
    }

    private fun panBy(dx: Float, dy: Float) {
        tx += dx
        // Scroll the list first (in unzoomed units); at the ends, move within the zoomed page instead.
        val want = -dy / zoom + scrollRemainder
        val step = want.toInt()
        scrollRemainder = want - step
        val dir = if (want > 0f) 1 else -1
        if (canScrollVertically(dir)) {
            if (step != 0) scrollBy(0, step)
        } else {
            ty += dy
            scrollRemainder = 0f
        }
        clamp()
        invalidate()
    }

    override fun dispatchDraw(canvas: Canvas) {
        canvas.save()
        canvas.translate(tx, ty)
        canvas.scale(zoom, zoom)
        super.dispatchDraw(canvas)
        canvas.restore()
    }
}

/** A frame whose content can be pinch-zoomed, panned and double-tapped (used for single page previews). */
class ZoomFrameLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : FrameLayout(context, attrs) {

    private var zoom = 1f
    private var tx = 0f
    private var ty = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var activeId = -1
    private val density = resources.displayMetrics.density

    /** Called on a left/right swipe when not zoomed: +1 = next page, -1 = previous page. */
    var onSwipe: ((Int) -> Unit)? = null

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            zoomTo(zoom * detector.scaleFactor, detector.focusX, detector.focusY)
            return true
        }
    })

    private val tapDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            zoomTo(if (zoom > 1.05f) 1f else DOUBLE_TAP_ZOOM, e.x, e.y)
            return true
        }

    })

    fun resetZoom() {
        zoom = 1f
        tx = 0f
        ty = 0f
        invalidate()
    }

    private fun zoomTo(target: Float, fx: Float, fy: Float) {
        val newZoom = target.coerceIn(1f, MAX_ZOOM)
        val f = newZoom / zoom
        tx = fx - (fx - tx) * f
        ty = fy - (fy - ty) * f
        zoom = newZoom
        clamp()
        invalidate()
    }

    private fun clamp() {
        if (zoom <= 1f) {
            zoom = 1f
            tx = 0f
            ty = 0f
            return
        }
        tx = tx.coerceIn(width - width * zoom, 0f)
        ty = ty.coerceIn(height - height * zoom, 0f)
    }

    private var downX = 0f
    private var downY = 0f
    private var multiTouch = false
    private var swipeVelocity: VelocityTracker? = null

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean = e.pointerCount > 1 || zoom > 1f

    /** A quick one-finger left/right flick while not zoomed = change page. */
    private fun checkSwipe(e: MotionEvent) {
        val vt = swipeVelocity ?: return
        vt.computeCurrentVelocity(1000)
        val dx = e.x - downX
        val dy = e.y - downY
        val fast = abs(vt.xVelocity) > 300f
        if (!multiTouch && zoom <= 1.05f && abs(dx) > abs(dy) * 1.5f && abs(dx) > 60f * density && fast) {
            onSwipe?.invoke(if (dx < 0) 1 else -1)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(e)
        tapDetector.onTouchEvent(e)
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            swipeVelocity?.recycle()
            swipeVelocity = VelocityTracker.obtain()
            downX = e.x
            downY = e.y
            multiTouch = false
        }
        swipeVelocity?.addMovement(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                activeId = e.getPointerId(0)
                lastX = e.x
                lastY = e.y
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_UP -> {
                checkSwipe(e)
                swipeVelocity?.recycle()
                swipeVelocity = null
            }
            MotionEvent.ACTION_CANCEL -> {
                swipeVelocity?.recycle()
                swipeVelocity = null
            }
            MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_POINTER_UP -> {
                multiTouch = true
                val leaving = if (e.actionMasked == MotionEvent.ACTION_POINTER_UP) e.actionIndex else -1
                for (i in 0 until e.pointerCount) {
                    if (i != leaving) {
                        activeId = e.getPointerId(i)
                        lastX = e.getX(i)
                        lastY = e.getY(i)
                        break
                    }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val idx = e.findPointerIndex(activeId)
                if (idx >= 0) {
                    val x = e.getX(idx)
                    val y = e.getY(idx)
                    if (!scaleDetector.isInProgress && zoom > 1f) {
                        tx += x - lastX
                        ty += y - lastY
                        clamp()
                        invalidate()
                    }
                    lastX = x
                    lastY = y
                }
            }
        }
        return true
    }

    override fun dispatchDraw(canvas: Canvas) {
        canvas.save()
        canvas.translate(tx, ty)
        canvas.scale(zoom, zoom)
        super.dispatchDraw(canvas)
        canvas.restore()
    }
}
