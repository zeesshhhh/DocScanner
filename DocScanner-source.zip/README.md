# DocScanner

A CamScanner-style document scanner for Android, built automatically into an APK by GitHub Actions.

## Features

- **Scan documents** with the camera: automatic edge detection, auto-capture, crop, rotate, filters (colour / grayscale / B&W), stain & finger removal, multi-page. Powered by Google ML Kit Document Scanner.
- **Add pages** to an existing document by scanning more.
- **Edit pages**: 4-corner crop, rotate, filters (Original / Enhance / Grayscale / Black & White, per page or all pages), move pages up/down or drag to reorder, delete, replace a page (new scan or image), add pages (scan, images or another PDF). Save over the original or as a new copy.
- **Recent**: a strip of your most recently opened or changed documents on the home screen.
- **Swipe left/right** through pages in the viewer (or switch to up/down scrolling in its menu); swipe past the last/first page to open the next/previous document. Swipe between pages in the editor too.
- **Pinch to zoom** (and double-tap) in the viewer and in the page editor; pages re-render sharp when zoomed.
- **Date, time & name stamp** in the bottom-left or bottom-right corner: pick the date and time, type a name, choose size and colour, apply to one page or all.
- **Stable document order**: editing no longer moves a document to the top. Use *Sort by…* for created date, last changed, name or size.
- **Replace document**: swap a document's contents for a new scan or a PDF from your phone, keeping its name.
- **Images → PDF**: turn gallery photos into one PDF (also works via *Share → DocScanner* from your gallery).
- **Merge PDFs**: combine documents from the app or from phone storage, drag to reorder pages' order.
- **Reduce file size**: Smallest / Balanced / High quality, with optional grayscale. Shows before → after size, and lets you replace the original.
- Built-in PDF viewer, rename, delete, share (WhatsApp, email…), save to phone, multi-select.

## Download the APK

1. Open the repo's **Releases** page (right side of the repo home page, or `/releases`).
2. Download the newest `DocScanner-v1.0.N.apk`.
3. Open it on your phone and allow *Install unknown apps* if asked.

Every push to `main` builds a new release automatically. You can also run it by hand: **Actions → Build APK → Run workflow**.

## Notes

- Requires Android 8.0+ and Google Play services (the scanner module downloads itself the first time, so be online for the first scan).
- The APK is signed with `keystore/docscanner.jks` (password `docscanner`) so new versions install over old ones. It's fine for personal use; if you ever publish the app, create your own private key and keep it out of the repo.
- Documents are stored privately inside the app. Use **Save to phone** or **Share** to get them out. Uninstalling the app deletes them.

## Build locally

Open the folder in Android Studio, or run `./gradlew assembleRelease`.
